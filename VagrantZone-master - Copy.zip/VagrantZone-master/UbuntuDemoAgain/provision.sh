sudo apt-get -y update

sudo apt-get -y install nginx




