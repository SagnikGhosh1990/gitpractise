#!/usr/bin/env bash
sudo apt-get -y update

sudo apt-get -y install apache2

